-- 6. Reporting

-- Monthly summary report  (sales, price, quantity).
SELECT  EXTRACT (YEAR FROM order_date) AS Years ,
		TO_CHAR(order_date , 'Mon') AS months ,
		SUM(sales) AS Sales_From_Months ,
		SUM(quantity) AS quantities_From_Months
FROM gold.orders_fact 
GROUP BY Years , months
ORDER BY Years;

-- Regional performance YEARLY.
SELECT EXTRACT (YEAR FROM oo.order_date) AS Years ,
		cst.country ,
		SUM(oo.sales) AS Sales_From_YEARLY
FROM gold.orders_fact oo LEFT JOIN gold.customer_dimention cst 
ON oo.customer_key = cst.customer_key 
GROUP BY Years , cst.country
ORDER BY Sales_From_YEARLY DESC , Years ;

-- Use `ROW_NUMBER()` to highlight latest order per customer. 

SELECT DENSE_RANK() OVER (PARTITION BY cst.firstname , cst.lastname  ORDER BY oo.order_date DESC) AS Rank__ ,
		cst.firstname , cst.lastname , 
		oo.order_number ,
		oo.order_date
FROM gold.orders_fact oo LEFT JOIN gold.customer_dimention cst 
ON oo.customer_key = cst.customer_key
ORDER BY cst.firstname , cst.lastname , oo.order_date DESC;

-- `SUM(Sales) OVER(PARTITION BY Month(Order_Date))` for monthly summaries.
SELECT distinct TO_CHAR(order_date , 'Mon') AS Months , 
	SUM(Sales) OVER(PARTITION BY TO_CHAR(order_date , 'Mon')) AS monthly_summaries
FROM gold.orders_fact ORDER BY monthly_summaries DESC ;

-- Create a customer-level summary report with total sales, quantity, and orders.
SELECT cst.firstname , cst.lastname ,
		SUM(oo.sales) AS Sales ,
		SUM(oo.quantity) AS quantity ,
		COUNT (oo.order_number) AS orders
FROM  gold.orders_fact oo LEFT JOIN gold.customer_dimention cst 
ON oo.customer_key = cst.customer_key
GROUP BY cst.firstname , cst.lastname 
ORDER BY cst.firstname , cst.lastname ;

-- Generate a category-wise sales report over time.
SELECT  EXTRACT (YEAR FROM order_date) AS years ,
		pd.category , SUM(sales) AS Sales 
FROM gold.orders_fact oo LEFT JOIN gold.product_dimention pd 
ON oo.product_key = pd.product_key
GROUP BY years , pd.category
ORDER BY  Sales DESC ,years ;

-- Report top 10 customers with sales and orders.
SELECT cst.firstname , cst.lastname ,
		COUNT(order_number) AS orders,
		SUM(sales) AS Sales
FROM gold.orders_fact oo LEFT JOIN gold.customer_dimention cst 
ON oo.customer_key = cst.customer_key
GROUP BY cst.firstname , cst.lastname
ORDER BY Sales DESC, orders LIMIT 10 ; -- top 10 customers For Sales
		--	orders DESC , sales ;    -- top 10 customers For Orders
			
-- Provide a yearly sales report with sub_category-wise breakdown.
SELECT EXTRACT (YEAR FROM order_date) AS years ,
		pd.sub_category , 
		SUM(sales) AS sales
FROM gold.orders_fact oo LEFT JOIN gold.product_dimention pd 
ON oo.product_key = pd.product_key
GROUP BY years , pd.sub_category
ORDER BY years , sales  DESC ;