SELECT * FROM bronze.src_cust_crm LIMIT 1000;

-- Check Null Values AND Duplicate

SELECT cst_id , COUNT(*) FROM bronze.src_cust_crm GROUP BY cst_id HAVING COUNT(*)>1;
SELECT * FROM bronze.src_cust_crm WHERE cst_id=29449;
SELECT * FROM (SELECT * ,
	ROW_NUMBER() OVER ( PARTITION BY cst_id ORDER BY cst_create_date DESC) AS last_ FROM bronze.src_cust_crm
	WHERE cst_id IS NOT NULL)
WHERE LAST_ = 1;

-- Check Unwanted Space 

SELECT cst_firstname FROM bronze.src_cust_crm WHERE TRIM(cst_firstname)<> cst_firstname;
SELECT cst_lastname FROM bronze.src_cust_crm WHERE TRIM(cst_lastname)<> cst_lastname;
SELECT cst_marital_status FROM bronze.src_cust_crm WHERE TRIM(cst_marital_status)<> cst_marital_status;
SELECT cst_gndr FROM bronze.src_cust_crm WHERE TRIM(cst_gndr)<> cst_gndr;

-- Standardization 

SELECT DISTINCT(cst_marital_status) FROM bronze.src_cust_crm ;
SELECT DISTINCT(cst_gndr) FROM bronze.src_cust_crm ;

SELECT cst_marital_status ,
CASE
	WHEN UPPER(cst_marital_status)='S' THEN 'Single'
	WHEN UPPER(cst_marital_status)='M' THEN 'Married'
	ELSE 'n/a'
END FROM bronze.src_cust_crm;
	
