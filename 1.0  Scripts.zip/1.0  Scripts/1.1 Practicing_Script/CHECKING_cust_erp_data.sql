SELECT * FROM bronze.src_cust_erp;

-- Clean Id 

SELECT cid , 
	CASE 
		WHEN cid LIKE 'NAS%' THEN SUBSTRING(cid , 4 , LENGTH(cid))
		ELSE cid
	END AS __cid__
FROM bronze.src_cust_erp;

SELECT cid FROM silver.src_cust_erp where cid LIKE 'NAS%';
-- Birthday

SELECT bdate FROM  bronze.src_cust_erp
	WHERE bdate > CURRENT_DATE ;

SELECT bdate FROM  bronze.src_cust_erp
	WHERE bdate < '1925-01-01' ;

SELECT bdate , 
	CASE
		WHEN bdate > CURRENT_DATE THEN NULL
		ELSE bdate
	END AS bdate
FROM bronze.src_cust_erp 
WHERE bdate > CURRENT_DATE;

-- Checking 

SELECT DISTINCT gen,
CASE 
	WHEN UPPER(TRIM(gen)) IN ('F' , 'FEMALE') THEN 'Female'
	WHEN UPPER(TRIM(gen)) IN ('M' , 'MALE') THEN 'Male'
	ELSE 'n/a'
END AS gen__
FROM bronze.src_cust_erp ; 

