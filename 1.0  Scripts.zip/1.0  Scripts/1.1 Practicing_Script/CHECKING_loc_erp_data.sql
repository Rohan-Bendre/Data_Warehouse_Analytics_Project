SELECT * FROM bronze.src_loc_erp;
SELECT * FROM silver.src_cust_crm;

-- Cleaning id

SELECT cid ,
	REPLACE(cid , '-','') AS cid
FROM bronze.src_loc_erp;
SELECT cid FROM SILVER.src_loc_erp;
-- Cleanin country
SELECT DISTINCT contry FROM bronze.src_loc_erp;

SELECT DISTINCT contry , 
	CASE 
		WHEN TRIM(contry)= 'DE' THEN 'Germany'
		WHEN TRIM(contry) IN ('US' , 'USA') THEN 'United States'
		WHEN TRIM(contry) IN ('n/a' , null ,'') THEN NULL
		ELSE contry
	END AS contry
FROM SILVER.src_loc_erp;