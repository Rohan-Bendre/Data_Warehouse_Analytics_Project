SELECT 
    DISTINCT cc.cst_gndr,
    ce.gen ,
	CASE 
		WHEN cc.cst_gndr <> 'n/a' THEN cc.cst_gndr
		ELSE COALESCE (ce.gen , 'n/a')
	END AS Gender
FROM silver.src_cust_crm cc LEFT JOIN silver.src_cust_erp ce
ON cc.cst_key = ce.cid;