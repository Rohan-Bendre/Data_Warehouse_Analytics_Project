SELECT * FROM bronze.src_ctg_erp;
SELECT * FROM silver.src_ctg_erp;
SELECT * FROM silver.src_prd_crm;

-- Check id 
-- IT's same

-- Unwanted Space 
Select * from bronze.src_ctg_erp
where cat<>TRIM(cat) OR subcat<> TRIM(subcat) OR maintenance<>TRIM(maintenance);

-- DISTINCT
SELECT DISTINCT CAT FROM bronze.src_ctg_erp;
SELECT DISTINCT SUBCAT FROM bronze.src_ctg_erp;
SELECT DISTINCT MAINTENANCE FROM bronze.src_ctg_erp;


