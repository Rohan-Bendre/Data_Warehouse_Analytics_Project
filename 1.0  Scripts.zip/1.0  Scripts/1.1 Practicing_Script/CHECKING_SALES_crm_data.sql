SELECT * FROM bronze.src_sales_details_crm;

-- Check Null Values
SELECT sls_ord_num FROM bronze.src_sales_details_crm WHERE sls_ord_num IS NULL;

-- Check Id's Relation in Table
SELECT * FROM bronze.src_sales_details_crm WHERE sls_prd_key NOT IN
(SELECT prd_key FROM silver.src_prd_crm );

SELECT * FROM bronze.src_sales_details_crm WHERE sls_cust_id NOT IN
(SELECT cst_id FROM silver.src_cust_crm );

-- Dates Cleaning
SELECT sls_order_dt FROM bronze.src_sales_details_crm WHERE sls_order_dt IS NULL OR sls_order_dt<=0 OR LENGTH(CAST(sls_order_dt AS TEXT))<>8;
SELECT sls_ship_dt FROM bronze.src_sales_details_crm WHERE sls_ship_dt IS NULL OR sls_ship_dt<=0 OR LENGTH(CAST(sls_order_dt AS TEXT))<>8;
SELECT sls_due_dt FROM bronze.src_sales_details_crm WHERE sls_due_dt IS NULL OR sls_due_dt<=0 OR LENGTH(CAST(sls_order_dt AS TEXT))<>8;

SELECT SLS_ORDER_DT ,
	CASE 
		WHEN sls_order_dt <=0 OR LENGTH(CAST(sls_order_dt AS TEXT))<>8 THEN NULL
		ELSE CAST(CAST(sls_order_dt AS TEXT) AS DATE)
	END AS sls_order_dt
FROM bronze.src_sales_details_crm;

SELECT SLS_SHIP_DT ,
	CASE 
		WHEN sls_ship_dt <=0 OR LENGTH(CAST(sls_ship_dt AS TEXT))<>8 THEN NULL
		ELSE CAST(CAST(sls_ship_dt AS TEXT) AS DATE)
	END AS sls_ship_dt
FROM bronze.src_sales_details_crm;

SELECT SLS_due_DT ,
	CASE 
		WHEN sls_due_dt <=0 OR LENGTH(CAST(sls_due_dt AS TEXT))<>8 THEN NULL
		ELSE CAST(CAST(sls_due_dt AS TEXT) AS DATE)
	END AS sls_due_dt
FROM bronze.src_sales_details_crm;

-- Business Logic

Select Distinct 
	sls_sales AS OLD_SALE,
	sls_quantity AS old_quantity,
	sls_price AS OLD_PRICE, 
	CASE 
		WHEN sls_sales <> sls_quantity * ABS(sls_price) OR sls_sales IS NULL OR sls_sales <=0
		THEN sls_quantity * ABS(sls_price)
		ELSE sls_sales
	END AS sls_sales,
	CASE 
		WHEN sls_price IS NULL OR sls_price<=0
		THEN sls_sales / sls_quantity
		ELSE sls_price
	END AS sls_price
FROM bronze.src_sales_details_crm 
WHERE sls_sales <> sls_quantity * sls_price OR sls_sales IS NULL OR sls_sales <=0
OR sls_quantity IS NULL OR sls_quantity <=0
OR sls_price IS NULL OR sls_price<=0
order by sls_sales, sls_quantity, sls_price; 