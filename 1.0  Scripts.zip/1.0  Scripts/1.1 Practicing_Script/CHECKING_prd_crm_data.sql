SELECT * FROM bronze.src_prd_crm LIMIT 1000;
SELECT * FROM bronze.src_ctg_erp LIMIT 1000;
SELECT * FROM bronze.src_sales_details_crm LIMIT 1000;
-- Check Null
SELECT PRD_ID FROM bronze.src_prd_crm WHERE PRD_ID IS NULL;

-- Derived Colomn 
SELECT prd_key , 
	REPLACE(SUBSTRING(prd_key ,1,5),'-','_') FROM bronze.src_prd_crm AS prd_id;

SELECT prd_key , 
	SUBSTRING(prd_key ,7,LENGTH(prd_key)) FROM bronze.src_prd_crm AS prd_key;

-- Unwanted Space
SELECT TRIM(PRD_NM) AS PN FROM  bronze.src_prd_crm;
SELECT TRIM(PRD_LINE) AS PL FROM  bronze.src_prd_crm;

-- clrsn
Select * FROM bronze.src_prd_crm WHERE PRD_COST IS NULL OR PRD_COST<=0;

SELECT prd_cost, COALESCE (prd_cost , 0 ) as ct from  bronze.src_prd_crm ;

-- Standardization 
SELECT
	CASE 
		WHEN UPPER(TRIM(prd_line))='S' THEN 'Other Sales'
		WHEN UPPER(TRIM(prd_line))='M' THEN 'Mountain'
		WHEN UPPER(TRIM(prd_line))='R' THEN 'Road'
		WHEN UPPER(TRIM(prd_line))='T' THEN 'Touring'
		ELSE 'n/a'
	END AS NW
FROM  bronze.src_prd_crm;

SELECT DISTINCT prd_line from  bronze.src_prd_crm;

-- DATA ENRICHMENT 

SELECT * , 
	LEAD(PRD_START_DT) OVER (PARTITION BY PRD_KEY ORDER BY PRD_START_DT)-1  AS PRD_END_DT 
FROM bronze.src_prd_crm;